﻿using System;

namespace BuildingACalculator
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter 1 for addition, 2 for subtraction, 3 for multiplication or 4 for division");
            string userInput = Console.ReadLine(); 
            

            if (userInput == "1")
            {
                Console.WriteLine("Please enter a number");
                double num1 = (Convert.ToDouble(Console.ReadLine()));
                Console.WriteLine("Please enter another number");
                double num2 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Your answer is: ");
                Console.WriteLine(num1 + num2);
            }


            else if (userInput == "2")
            {
                Console.WriteLine("Please enter a number");
                double num3 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter another number");
                double num4 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Your answer is: ");
                Console.WriteLine(num3 - num4);
            }
            else if (userInput == "3")
            {
                Console.WriteLine("Please enter a number");
                double num5 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter another number");
                double num6 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Your answer is: ");
                Console.WriteLine(num5 * num6);
            }

            else if (userInput == "4")

            {
                Console.WriteLine("Please enter a number");
                double num7 = (Convert.ToDouble(Console.ReadLine()));
                Console.WriteLine("Enter another number");
                double num8 = (Convert.ToDouble(Console.ReadLine()));
                Console.WriteLine("Your answer is: ");
                Console.WriteLine(num7 / num8);

          













            }



        }


    }
}
